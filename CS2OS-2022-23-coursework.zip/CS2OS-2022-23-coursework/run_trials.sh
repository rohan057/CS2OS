#!/bin/bash
# This file is for Part 1 of the coursework
# Write your for loop below:

