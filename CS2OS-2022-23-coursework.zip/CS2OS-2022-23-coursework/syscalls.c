/* This file is for Part 2 of the coursework */

#include <unistd.h>         // for syscall(), open(), etc
#include <sys/syscall.h>    // for the SYS_xxx call codes
#include <fcntl.h>          // for the file modes


int main(int argc, char** argv) {
    const char* ifname = "input.txt";
    const char* ofname = "output.txt";

    // Todo: if the first parameter is 's':
    // your code here
    {
        /** Todo: use the syscall() function to copy 256 bytes
         *  of input.txt to output.txt
         */

        // your code here
    }
    // Todo: else the first parameter is 'w':
    // your code here
    {
        /** Todo: use the wrapper functions to copy 256 bytes
         *  of input.txt to output.txt
         */

        // your code here 
    }


    /******/
    return 0;
}